﻿using System.Globalization;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Timers;

namespace ConsoleApp1
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //    "00-08-9B-F8-2D-9B", 
            //    "00-08-9B-F8-2D-9C",

            // Source - https://stackoverflow.com/q/13634868

            //string host = Dns.GetHostName();
            //IPHostEntry ip = Dns.GetHostEntry(host);
            //IPAddress[] address = ip.AddressList;

            //Console.WriteLine(ip.AddressList[0].ToString());

            //WOL.WakeOnLan1.Broadcast("00-08-9B-F8-2D-9B", 7);
            //WOL.MagicPacket.Broadcast("00-08-9B-F8-2D-9B", 9); //OK
            //WOL.WakeOnLan1.Broadcast("00-08-9B-F8-2D-9B", 40000);

            //Task task = WOL.MagicPack.WakeOnLan("00-08-9B-F8-2D-9B");
            //task.Wait(); //resolve, bad, but for testing purposes it's fine

            WOL.MagicPacket.BroadcastB("00-08-9B-F8-2D-9B", 9); //OK
            Console.WriteLine("Wake-on-LAN packet sent.");
        }
    }
}