﻿using System.Globalization;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection.Metadata.Ecma335;
using System.Text.RegularExpressions;

namespace WOL
{
    public static class MagicPacket
    {
        public static void Broadcast(string macAddress, int port = 9)
        {
            byte[] magicPacket = BuildMagicPacket(macAddress);

            SendWakeOnLan(port, magicPacket);
        }

        public static void BroadcastB(string macAddress, int port = 9)
        {
            string[] ips1 = GetLocalIPAddressV1();
            IPAddress ip2 = GetLocalIPAddressV2();
            string ip3 = GetLocalIPAddressV3();

            IPAddress ipDg1 = GetDefaultGatewayV1();
            IPAddress ipDg2 = GetLocalIPAddressV2();
            string ipDg3 = GetLocalIPAddressV3();

            GetAllLocalIPAddresses2();

            //224.0.0.1 is the reserved "All-Hosts" multicast group address,
            //used to communicate with all multicast-capable devices on a local network segment(subnet)
            const string MulticastIp = "224.0.0.1";

            byte[] magicPacket = BuildMagicPacket(macAddress);

            string bBroadcastIp = IPAddress.Broadcast.ToString(); //  
            IPAddress xx =GetDefaultGatewayV1();
            string[] xpto = GetLocalIPAddressV1();


           // string localIp =
      

            IPAddress localIpAddress = IPAddress.Parse("192.168.1.12");
            IPAddress multicastIpAddress = IPAddress.Parse(MulticastIp);

            SendWakeOnLanB(localIpAddress, multicastIpAddress, port, magicPacket);
        }

        private static void SendWakeOnLan(int port, byte[] magicPacket)
        {
            using UdpClient client = new UdpClient() { EnableBroadcast = true };
            client.Connect(IPAddress.Broadcast, port);
            client.Send(magicPacket, magicPacket.Length);
        }

        private static void SendWakeOnLanB(IPAddress localIpAddress, IPAddress multicastIpAddress, int port, byte[] magicPacket)
        {
            IPEndPoint localIpEndPoint = new(localIpAddress, 0);
            IPEndPoint multicastIpEndPoint = new(multicastIpAddress, port);

            using UdpClient client = new(localIpEndPoint);
            client.Send(magicPacket, magicPacket.Length, multicastIpEndPoint);
        }

        private static string GetCleanMacAddress(string macAddress)
        {
            string cleanMacAddress = macAddress.Replace(":", "").Replace("-", "").Replace(" ", "").ToUpper();

            if (cleanMacAddress.Length != 12)
                throw new ArgumentException($"Invalid MAC address length. [{macAddress}]");

            bool ok = cleanMacAddress.All(c => (Char.IsLetter(c) && Char.IsUpper(c)) || Char.IsDigit(c));
            if (!ok)
                throw new ArgumentException($"Invalid MAC address format. [{macAddress}]");

            return cleanMacAddress;
        }

        private static byte[] BuildMagicPacket(string macAddress)
        {
            string cleanMacAddress = GetCleanMacAddress(macAddress);

            int counter = 0;
            byte[] dataArray = new byte[102];

            //header: 6 times with 0xff
            for (int x = 0; x < 6; x++)
                dataArray[counter++] = 0xFF;

            //data: 16 times with the mac address
            for (int x = 0; x < 16; x++)
            {
                for (int macBytes = 0; macBytes < 12; macBytes += 2)
                {
                    string temp = cleanMacAddress.Substring(macBytes, 2);
                    dataArray[counter++] = byte.Parse(temp, NumberStyles.HexNumber);
                }
            }

            return dataArray;

            //another way to do it 
            //byte[] macBytes = Convert.FromHexString(cleanMacAddress);
            //IEnumerable<byte> header = Enumerable.Repeat((byte)0xff, 6); //First 6 times 0xff
            //IEnumerable<byte> data = Enumerable.Repeat(macBytes, 16).SelectMany(m => m); // then 16 times MacAddress
            //return header.Concat(data).ToArray();
        }






        private static void GetAllLocalIPAddresses2()
        {
            string hostName = Dns.GetHostName();

            IPAddress[] iPAddressArray = Dns.GetHostAddresses(hostName);

            foreach (IPAddress ipAddress in iPAddressArray)
            {
                Console.WriteLine($"---------------------------------------: {ipAddress.ToString()}");

                if (ipAddress.IsIPv6LinkLocal)
                    Console.WriteLine($"IP Address IsIPv6LinkLocal");

                if (ipAddress.AddressFamily == AddressFamily.InterNetwork)
                    Console.WriteLine($"IP Address V4: {ipAddress.ToString()}");

                if (ipAddress.AddressFamily == AddressFamily.InterNetworkV6)
                    Console.WriteLine($"IP Address V6: {ipAddress.ToString()}");
            }
        }

        private static string[] GetLocalIPAddressV1()
        {
            var ipList = NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up)
                .SelectMany(n => n.GetIPProperties().UnicastAddresses)
                .Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork)
                .Select(a => a.Address.ToString())
                .ToArray();

            return ipList;
        }

        private static IPAddress GetLocalIPAddressV2() //GetPrivateIP
        {
            // IPAddress ipAddressGateway = GetDefaultGateway();
            // string ipGateway = ipAddressGateway.ToString();


            NetworkInterface[] networkInterfaceArray = NetworkInterface.GetAllNetworkInterfaces();

            //foreach (NetworkInterface networkInterface in networkInterfaceArray)
            //{
            //    if (networkInterface.OperationalStatus != OperationalStatus.Up)
            //        continue;

            //    if (networkInterface.NetworkInterfaceType == NetworkInterfaceType.Loopback)
            //        continue;

            //    IPInterfaceProperties properties = networkInterface.GetIPProperties();
            //    GatewayIPAddressInformationCollection GatewayCollection = properties.GatewayAddresses;

            //    foreach (GatewayIPAddressInformation gatewayInfo in GatewayCollection)
            //    {
            //        var returnz= networkInterface;
            //    }

            //}

            //      return null;






            //     NetworkInterface[] networkInterfaceArray = NetworkInterface.GetAllNetworkInterfaces();

           // IPAddress? localIPAdress = null;

            foreach(var networkInterface in networkInterfaceArray)
            {

                if (networkInterface.OperationalStatus != OperationalStatus.Up)
                    continue;


                IPInterfaceProperties properties = networkInterface.GetIPProperties();
                GatewayIPAddressInformationCollection GatewayCollection = properties.GatewayAddresses;

                bool hasAddressGateway = false;

                foreach(GatewayIPAddressInformation gatewayInfo in GatewayCollection)
                {
                    hasAddressGateway = true;
                    break;
                }

                if (!hasAddressGateway)
                    continue;

                UnicastIPAddressInformationCollection addressCollectionArray = networkInterface.GetIPProperties().UnicastAddresses;
                foreach(var addressItem in addressCollectionArray)
                {
                    Console.WriteLine($"Network Address: {addressItem.Address.ToString()}");
                    Console.WriteLine($"Network Address family: {addressItem.Address.AddressFamily.ToString()}");

                    //if (addressItem.Address.AddressFamily == AddressFamily.InterNetworkV6) // V6
                    //{
                    //    Console.WriteLine($"Network Interface UnicastAddresses V6: {addressItem.Address.ToString()}");
                    //}

                    if (addressItem.Address.AddressFamily == AddressFamily.InterNetwork) // V4
                    {
                        //localIPAdress = addressItem.Address;
                        Console.WriteLine($"Network Interface UnicastAddresses V4: {addressItem.Address.ToString()}");
                        return addressItem.Address;
                    }


                }

            }
        
            throw new Exception("No network adapters with an IPv4 address in the system!");

            
            //// var xx = networkInterfaceArray.Where(n => n.OperationalStatus == OperationalStatus.Up)
            ////    .Where(n => n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
            ////    .SelectMany(n => n.GetIPProperties()?.GatewayAddresses)
            ////    .Select(g => g?.Address)
            ////    .Where(a => a != null)
            //// .Where(a => a.AddressFamily == AddressFamily.InterNetwork)
            //// .Where(a => Array.FindIndex(a.GetAddressBytes(), b => b != 0) >= 
            //var zzz = NetworkInterface
            //   .GetAllNetworkInterfaces()
            //   .Where(n => n.OperationalStatus == OperationalStatus.Up)
            //   .Where(n => n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
            //   .SelectMany(n => n.GetIPProperties()?.GatewayAddresses)
            //   .Select(g => g?.Address)
            //   .Where(a => a != null)
            //   // .Where(a => a.AddressFamily == AddressFamily.InterNetwork)
            //   // .Where(a => Array.FindIndex(a.GetAddressBytes(), b => b != 0) >= 0)
            //   .FirstOrDefault();


            //string hostName = Dns.GetHostName();
            //Console.WriteLine(hostName);

            //// Get the IP from GetHostByName method of dns class.
            //var xpto = Dns.GetHostByName(hostName);
            //string IP = xpto.AddressList[0].ToString();





            //// Source - https://stackoverflow.com/q/13634868
            //// Posted by Frecklefoot, modified by community. See post 'Timeline' for change history
            //// Retrieved 2026-03-14, License - CC BY-SA 3.0

            //GatewayIPAddressInformationCollection gwc =
            //    System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces()[0].GetIPProperties().GatewayAddresses;

            //string aaaa = gwc[0].Address.ToString();

            //IPAddress destinatario = IPAddress.Broadcast;
            //string xxxx = destinatario.ToString();




            //var networkInterface = NetworkInterface.GetAllNetworkInterfaces();
            ////Dim myAdapterProps As IPInterfaceProperties = Nothing
            ////Dim myGateways As GatewayIPAddressInformationCollection = Nothing

            //foreach (var adapter in networkInterface)
            //{
            //    var myAdapterProps = adapter.GetIPProperties;

            //    var myGateways = myAdapterProps;// ..GatewayAddresses();

            //    //foreach (var gateway in myGateways)
            //    //{
            //    //    Console.WriteLine($"Router IP is {gateway.Address.ToString()}");
            //    //}
            //}









            //IPHostEntry host1 = Dns.GetHostEntry(Dns.GetHostName());

            //foreach (IPAddress ip in host1.AddressList)
            //{
            //    string? aa = ip.ToString();
            //    if (ip.AddressFamily == AddressFamily.InterNetwork)
            //    {
            //        Console.WriteLine($"return {ip.ToString()}");
            //        //Console.WriteLine($"return {ip..Address..ToString()}");
            //        //192.168.1.1
            //    }
            //}
            //throw new Exception("No network adapters with an IPv4 address in the system!");


            //var host = Dns.GetHostEntry(Dns.GetHostName());
            //var ipAddress = host.AddressList
            //    .FirstOrDefault(ip => ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);

            //if (ipAddress == null)
            //    throw new Exception("No IPv4 address found for this machine.");

            //return ipAddress.ToString();
        }

        private static string GetLocalIPAddressV3() //GetPrivateIP
        {
            string hostName = Dns.GetHostName();
            IPAddress[] iPAddressArray = Dns.GetHostAddresses(hostName);

            foreach (IPAddress ipAddress in iPAddressArray)
            {
                Console.WriteLine(ipAddress.ToString());
                if (ipAddress.AddressFamily == AddressFamily.InterNetwork)
                {
                    Console.WriteLine("--->" + ipAddress.ToString());
                    //return ipAddress.ToString();
                }
            }

            return "";
        }

        private static async Task<string> GetPublicIPAddressAsync()
        {
            using (var client = new HttpClient())
            {
                string url = "https://api.ipquery.io";
                var response = await client.GetStringAsync(url);
                return response.Trim();
            }
        }




        private static string GetPublicIP()
        {
            string address = "";
            WebRequest request = WebRequest.Create("http://www.google.com");

            using WebResponse response = request.GetResponse();

            using StreamReader stream = new StreamReader(response.GetResponseStream());
            address = stream.ReadToEnd();


            int first = address.IndexOf("Address: ") + 9;
            int last = address.IndexOf("</body>");

            address = address.Substring(first, last - first);

            return address;
        }

        //public static IPAddress GetDefaultGateway()
        //{
        //    return NetworkInterface
        //        .GetAllNetworkInterfaces()
        //        .Where(n => n.OperationalStatus == OperationalStatus.Up)
        //        .Where(n => n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
        //        .SelectMany(n => n.GetIPProperties()?.GatewayAddresses)
        //        .Select(g => g?.Address)
        //        .Where(a => a != null)
        //        // .Where(a => a.AddressFamily == AddressFamily.InterNetwork)
        //        // .Where(a => Array.FindIndex(a.GetAddressBytes(), b => b != 0) >= 0)
        //        .FirstOrDefault();
        //}

        public static IPAddress GetDefaultGatewayV1()
        {
            
            NetworkInterface[] networkInterfaceArray = NetworkInterface.GetAllNetworkInterfaces();

            foreach (NetworkInterface networkInterface in networkInterfaceArray)
            {
                if (networkInterface.OperationalStatus != OperationalStatus.Up)
                    continue;

                if (networkInterface.NetworkInterfaceType == NetworkInterfaceType.Loopback)
                    continue;

                IPInterfaceProperties properties = networkInterface.GetIPProperties();
                GatewayIPAddressInformationCollection GatewayCollection = properties.GatewayAddresses;

                foreach (GatewayIPAddressInformation gatewayInfo in GatewayCollection)
                {
                    return gatewayInfo.Address;
                }

            }

            throw new Exception("No default gateway found.");
        }

        public static IPAddress GetDefaultGatewayV2()
        {
            return NetworkInterface.GetAllNetworkInterfaces()[0].GetIPProperties().GatewayAddresses[0].Address;
        }

        public static IPAddress GetDefaultGatewayV3()
        {
            IPAddress? iPAddress = NetworkInterface
                    .GetAllNetworkInterfaces()
                    .Where(n => n.OperationalStatus == OperationalStatus.Up)
                    .Where(n => n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                    .SelectMany(n => n.GetIPProperties().GatewayAddresses)
                    .Select(g => g.Address)
                    .FirstOrDefault(a => a != null);

            return iPAddress ?? throw new Exception("No default gateway found.");
        }

    }
}

